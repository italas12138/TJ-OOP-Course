﻿#include <iostream>  
#include <iomanip>     
#include <graphics.h>  
#include <math.h>  
#include <conio.h>  
#include <time.h>  
using namespace std;
#define PI 3.1415926  

struct Point {
    int x;
    int y;
};


struct tm t;
time_t now;

const int circle_x = 400;
const int circle_y = 300;
const int circle_radis = 252;

int startX = circle_x - circle_radis;       //正弦函数起始坐标
int endX = circle_x + circle_radis;         //正弦函数终止坐标

double amplitude = (2*circle_radis) / PI;  // 正弦函数的振幅

int sin_x[2 * circle_radis + 1];          //储存上面的正弦函数与x坐标之间的关系
int sin_y[2 * circle_radis + 1];          //储存下面的正弦函数与x坐标之间的关系
int r[2 * circle_radis + 1];              //实现渐变色
int b[2 * circle_radis + 1];

void init();          //初始化
void init_sec();      //初始化秒针
void pic_again(int hour, int min, int sec);    //再次绘画时间
void new_hour();      //绘制新的时针
void new_min();       //绘制新的分针
void new_sec();       //绘制新的秒针
void sin_xy();        //因为需要计算正弦函数，所以封装了一个计算过程
void buffer_sin();

//封装一个混合颜色的函数，利用ALpha实现抗锯齿
COLORREF mix_color(COLORREF bg, COLORREF color, double alpha);
//画一个没有锯齿的圆
void SDF_circle(Point p, COLORREF color, int r, double line_width);




void init()
{

    cleardevice();

    setbkcolor(COLORREF(BLACK));

    init_sec();

    new_sec();
    new_hour();
    new_min();

}

void init_sec()
{
    double line_width = 5;

    Point p;
    p.x = circle_x;
    p.y = circle_y;
    SDF_circle(p, WHITE, circle_radis, line_width / 2);

    buffer_sin();
}

void pic_again(int hour, int min, int sec)
{
    BeginBatchDraw();

    new_sec();
    new_hour();
    new_min();

    FlushBatchDraw();

    EndBatchDraw();
}

void sin_xy() {
    for (int x = startX; x <= endX; ++x)
    {
        double radian = (x - startX) * 1.0 / (circle_radis)*PI;  // 角度转弧度
        double y = circle_y - sin(radian) * amplitude;  // 计算正弦函数值的y坐标

        sin_x[x - startX] = int(circle_y - sin(radian) * amplitude);
        sin_y[x - startX] = int(circle_y + sin(radian) * amplitude);
        r[x - startX] = (x - startX) / 2;
        b[x - startX] = 255 - (x - startX) / 2;
    }
}

void buffer_sin()
{

    int hour_num = 5;
    TCHAR abc[20];

    for (int x = startX; x <= endX; ++x)
    {
        setcolor(RGB(r[x - startX], 0, b[x - startX]));
        line(x, sin_x[x - startX] - 2, x, sin_x[x - startX] + 2);

        setcolor(WHITE);
        settextstyle(16, 0, _T("SimSun"));
        if ((x - startX) % (circle_radis / 3) == 0 && x != startX && x != endX)
        {
            if (x <= circle_x)
            {
                line(x, sin_x[x - startX] - 3, x, sin_x[x - startX] - 12);
                _stprintf_s(abc, _T("%02d"), hour_num);		// 高版本 VC 推荐使用 _stprintf_s 函数
                outtextxy(x - 8, sin_x[x - startX] - 30, abc);
                hour_num += 5;
            }
            else
            {
                line(x, sin_x[x - startX] + 3, x, sin_x[x - startX] + 12);
                _stprintf_s(abc, _T("%02d"), hour_num);		// 高版本 VC 推荐使用 _stprintf_s 函数
                outtextxy(x - 8, sin_x[x - startX] + 15, abc);
                hour_num += 5;
            }

        }
    }

    hour_num = 35;

    for (int x = endX; x >= startX; --x)
    {

        setcolor(RGB(r[x - startX], 0, b[x - startX]));
        line(x, sin_y[x - startX] - 2, x, sin_y[x - startX] + 2);

        setcolor(WHITE);
        settextstyle(16, 0, _T("SimSun"));
        if ((x - startX) % (circle_radis / 3) == 0 && x != startX && x != endX)
        {
            if (x > circle_x)
            {
                line(x, sin_y[x - startX] - 3, x, sin_y[x - startX] - 12);
                _stprintf_s(abc, _T("%02d"), hour_num);		// 高版本 VC 推荐使用 _stprintf_s 函数
                outtextxy(x - 8, sin_y[x - startX] - 30, abc);
                hour_num += 5;
            }
            else
            {
                line(x, sin_y[x - startX] + 3, x, sin_y[x - startX] + 12);
                _stprintf_s(abc, _T("%02d"), hour_num);		// 高版本 VC 推荐使用 _stprintf_s 函数
                outtextxy(x - 8, sin_y[x - startX] + 15, abc);
                hour_num += 5;
            }

        }

    }


}

COLORREF mix_color(COLORREF bg, COLORREF color, double alpha)
{
    COLORREF result;
    int r = int(GetRValue(bg) * (1 - alpha) + GetRValue(color) * alpha);
    int g = int(GetGValue(bg) * (1 - alpha) + GetGValue(color) * alpha);
    int b = int(GetBValue(bg) * (1 - alpha) + GetBValue(color) * alpha);
    result = RGB(r, g, b);
    return result;
}

void SDF_circle(Point p, COLORREF color, int r, double line_width)
{
    for (int i = p.x - r - 10; i < p.x + r + 10; i++) {      //所画的x的变化区域
        for (int j = p.y - r - 10; j < p.y + r + 10; j++) {  //所画的y的变化区域
            Point p1 = { i,j };            //其中任一点的坐标
            double d;                      //与圆形的距离

            d = abs(sqrt((pow(p1.x - p.x, 2) + pow(p1.y - p.y, 2))) - r - line_width);
            //由于圆边有宽度，所以取绝对值进行了一定的处理

            double alpha = 0.5 - (d - line_width);  //计算Alpha值
            if (d <= line_width) {                  //圆宽度内涂白
                putpixel(i, j, WHITE);
            }
            if (alpha >= 0 && alpha <= 1) {         //边缘化进行混合颜色处理
                COLORREF bg = getbkcolor(); 
                COLORREF result = mix_color(bg, color, alpha);
                putpixel(i, j, result);
            }
        }
    }
}

void new_hour()
{
    clearcircle(circle_x - circle_radis / 2, circle_y, circle_radis / 4);

    settextstyle(30, 0, _T("SimSun"));
    setcolor(WHITE);

    TCHAR s[20];
    _stprintf_s(s, _T("%02d"), t.tm_hour);
    outtextxy(275-15, 300-15, s);

    double line_width = 3;

    Point p1;
    p1.x = circle_x - circle_radis / 2;
    p1.y = circle_y;
    
    SDF_circle(p1, WHITE, circle_radis / 4, line_width / 2);

    int hour_pie_x;
    int hour_pie_y;
    double hour_pie_radis = t.tm_hour * 1.0 / 6 * PI + t.tm_min * 1.0 / 360 * PI;

    hour_pie_x = int(circle_x - circle_radis / 2 + circle_radis / 4 * 0.75 * sin(hour_pie_radis));
    hour_pie_y = int(circle_y - circle_radis / 4 * 0.75 * cos(hour_pie_radis));


    Point p2;
    p2.x = hour_pie_x;
    p2.y = hour_pie_y;

    SDF_circle(p2, WHITE, circle_radis / 16, line_width / 2);

}

void new_min()
{
    clearcircle(circle_x + circle_radis / 2, circle_y, circle_radis / 4);

    settextstyle(30, 0, _T("SimSun"));
    setcolor(WHITE);

    TCHAR str[20];
    _stprintf_s(str, _T("%02d"), t.tm_min);
    outtextxy(525-15, 300-15, str);

    double line_width = 3;
    Point p1;
    p1.x = circle_x + circle_radis / 2;
    p1.y = circle_y;

    setlinestyle(PS_SOLID | PS_ENDCAP_FLAT, 3);

    int min_pie_x;
    int min_pie_y;

    double min_pie_radis = t.tm_min * 1.0 / 30 * PI + t.tm_sec * 1.0 / 1800 * PI;
    min_pie_x = int(circle_x + circle_radis / 2 + circle_radis / 4 * 0.75 * sin(min_pie_radis));
    min_pie_y = int(circle_y - circle_radis / 4 * 0.75 * cos(min_pie_radis));

    Point p2;
    p2.x = min_pie_x;
    p2.y = min_pie_y;
    SDF_circle(p1, WHITE, circle_radis / 4, line_width / 2);
    SDF_circle(p2, WHITE, circle_radis / 16, line_width / 2);

}

void new_sec()
{
    setlinestyle(PS_SOLID | PS_ENDCAP_FLAT, 5);
    clearcircle(circle_x, circle_y, circle_radis);

    init_sec();

    double hour_bar_one = startX;
    double hour_bar_two = endX;

    setlinestyle(PS_SOLID | PS_ENDCAP_FLAT, 1);

    if (t.tm_sec < 30) {
        hour_bar_one = startX + (circle_radis * 1.0 / 15) * t.tm_sec;
    }
    else {
        hour_bar_one = endX;
        hour_bar_two = endX - (circle_radis * 1.0 / 15) * (t.tm_sec - 30);
    }

    for (int x = startX; x <= int(hour_bar_one); ++x)
    {
        setcolor(RGB(r[x - startX], 0, b[x - startX]));
        line(x, sin_x[x - startX] + 2, x, circle_y);
    }

    for (int x = endX; x >= int(hour_bar_two); --x)
    {
        setcolor(RGB(r[x - startX], 0, b[x - startX]));
        line(x, sin_y[x - startX] - 2, x, circle_y);
    }

}

int main()
{
    time(&now);
    localtime_s(&t, &now);	// 获取当地时间


    initgraph(800, 600);	// 图形方式初始化
    sin_xy();
    init();			// 自定义图形初始化函数，用于绘制时钟界面

    int cur_hour = t.tm_hour;
    int cur_min = t.tm_min;
    int cur_sec = t.tm_sec;

    while (!_kbhit())	// 无键盘操作时进入循环
    {
        time(&now);
        localtime_s(&t, &now);	// 获取当地时间

        if (cur_sec != t.tm_sec)
        {
            pic_again(t.tm_hour, t.tm_min, t.tm_sec);

            cur_hour = t.tm_hour;
            cur_min = t.tm_min;
            cur_sec = t.tm_sec;
        }
    }
    _getch();		// 按任意键准备退出时钟程序
    closegraph();		// 退出图形界面
    return 0;
}

